from __future__ import print_function
import os
import random
import geopandas as gpd 
import pysal as ps
import numpy as np
import pandas as pd
